# Imports
import pathlib
import numpy as np
import torch
from skimage.io import imread
from skimage.transform import resize
import matplotlib.pyplot as plt
from Architecture.unet.unet import UNet

from pytorch_grad_cam import GradCAM

from torchvision.models.segmentation import fcn_resnet50

# from densenet import DenseNet
from Architecture.Densenet.densenet import DenseNet
import segmentation_models_pytorch as smp
from torchvision import transforms
from PIL import Image

from Architecture.dataloader.transformations import normalize_01, re_normalize

# predict directory
predict_directory = pathlib.Path.cwd() / "dataset/mask"
segmented_directory = pathlib.Path.cwd() / "dataset/segmented"

# device
if torch.cuda.is_available():
    device = torch.device("cuda")
else:
    torch.device("cpu")

# device
if torch.cuda.is_available():
    device = torch.device("cuda")
else:
    device = torch.device("cpu")

model_choosed = input(
    "\n\nCHOOSE MODEL FOR PREDICTION:\n-UNet (u)\n-DenseNet (d)\n-pretrained(p)\n"
)
if model_choosed == "unet" or model_choosed == "u":
    # model
    model = UNet(
        in_channels=3,
        out_channels=2,
        n_blocks=4,
        start_filters=32,
        activation="relu",
        normalization="batch",
        conv_mode="same",
        dim=2,
    ).to(device)

    # get saved model
    model_name = "unet.pt"
elif model_choosed == "p":
    model = smp.Unet(
        encoder_name="efficientnet-b7",  # choose encoder, e.g. mobilenet_v2 or efficientnet-b7
        encoder_weights="imagenet",  # use `imagenet` pre-trained weights for encoder initialization
        in_channels=3,  # model input channels (1 for gray-scale images, 3 for RGB, etc.)
        classes=2,  # model output channels (number of classes in your dataset)
        encoder_depth=5,
    )
    model_name = "pretained.pt"
else: 
    model_choosed == "densenet" or model_choosed == "d":
    model = DenseNet(num_classes=2)
    # model = torch.hub.load("pytorch/vision:v0.10.0", "densenet121", pretrained=False)
    model_name = "densenet_saved.pt"

model_weights = torch.load(pathlib.Path.cwd() / model_name)

model.load_state_dict(model_weights)

def predict_densenet(
    img, model, preprocess, postprocess, device,
):
    # model.eval()
    input_tensor = preprocess(img)  # preprocess image
    input_batch = input_tensor.unsqueeze(
        0
    )  # create a mini-batch as expected by the model

    # move the input and model to GPU for speed if available
    if torch.cuda.is_available():
        input_batch = input_batch.to("cuda")
        model.to("cuda")

    with torch.no_grad():
        output = model(input_batch)
    # Tensor of shape 1000, with confidence scores over Imagenet's 1000 classes
    print(output[0])
    # The output has unnormalized scores. To get probabilities, you can run a softmax on it.
    probabilities = torch.nn.functional.softmax(output[0], dim=0)
    print("probabilities: ")
    print(probabilities)

    # Show top categories per image
    top5_prob, top5_catid = torch.topk(probabilities, 2)
    for i in range(top5_prob.size(0)):
        print("prob", top5_prob[i].item())

    return probabilities


def predict(
    img, model, preprocess, postprocess, device,
):
    model.eval()
    img = preprocess(img)  # preprocess image
    x = torch.from_numpy(img).to(device)  # to torch, send to device
    with torch.no_grad():
        out = model(x)  # send through model/network
    if model_choosed == "d":
        out_softmax = torch.softmax(out[0], dim=0)  # perform softmax on outputs
        result = postprocess(out_softmax)  # postprocess outputs
    else:
        out_softmax = torch.softmax(out, dim=1)  # perform softmax on outputs
        benign_mask = out_softmax[0, :, :, :].argmax(axis=0).detach().cpu().numpy()
        result = postprocess(out_softmax)  # postprocess outputs
    return result, benign_mask


# preprocess function
def preprocess(img: np.ndarray):
    img = np.moveaxis(img, -1, 0)  # from [H, W, C] to [C, H, W]
    # img = normalize_01(img)  # linear scaling to range [0-1]
    img = np.expand_dims(img, axis=0)  # add batch dimension [B, C, H, W]
    img = img.astype(np.float32)  # typecasting to float32
    return img


# postprocess function
def postprocess(img: torch.tensor):
    img = torch.argmax(img, dim=1)  # perform argmax to generate 1 channel
    img = img.cpu().numpy()  # send to cpu and transform to numpy.ndarray
    img = np.squeeze(img)  # remove batch dim and channel dim -> [H, W]
    img = re_normalize(img)  # scale it to the range [0-255]
    return img


def re_normalize(img):
    img = img.astype("float64")
    img *= 255.0 / img.max()
    return img


# predict segmentation maps
path_benign_image = "benign/norm-benign2_1.jpg"
img = imread(predict_directory / path_benign_image)
img_densenet = Image.open(predict_directory / path_benign_image)

if model_choosed == "d":
    preprocess_densenet = transforms.Compose(
        [
            transforms.Resize(256),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ]
    )
    output = predict_densenet(
        img_densenet, model, preprocess_densenet, postprocess, device
    )
else:
    output, benign_mask = predict(img, model, preprocess, postprocess, device)

print(model)
print(output)

im = Image.fromarray(output)
im = im.convert("L")
im.save(segmented_directory / "test.jpg")
print(f"output = shape: {output.shape}; type: {output.dtype}")
print(benign_mask)

# plt.imshow(output)

class SemanticSegmentationTarget:
    def __init__(self, category, mask):
        self.category = category
        self.mask = torch.from_numpy(mask)
        if torch.cuda.is_available():
            self.mask = self.mask.cuda()
        
    def __call__(self, model_output):
        return (model_output[self.category, :, : ] * self.mask).sum()


# GradCam
'''sem_classes = ['0', '1']
sem_class_to_idx = {cls: idx for (idx, cls) in enumerate(sem_classes)}
benign_category = sem_class_to_idx["0"]
car_mask_float = np.float32(benign_mask == benign_category)

target_layers = [model.model.backbone.layer4]
targets = [SemanticSegmentationTarget(benign_category, car_mask_float)]
with GradCAM(model=model,
             target_layers=target_layers,
             use_cuda=torch.cuda.is_available()) as cam:
    grayscale_cam = cam(input_tensor=img,
                        targets=targets)[0, :]
    # cam_image = show_cam_on_image(rgb_img, grayscale_cam, use_rgb=True)

#Image.fromarray(cam_image) '''