import torch
from Architecture.unet.unet import ActivationFunction, ConvMode, Dimensions, NormalizationLayer, UNet, UpMode

def test_unet_2d_up_modes(up_mode):
    batch_size = 1
    in_channels = 3
    out_channels = 2
    height = 256
    width = 256
    unet = UNet(
        in_channels=in_channels,
        out_channels=out_channels,
        n_blocks=4,
        start_filters=32,
        activation=ActivationFunction.RELU,
        normalization=NormalizationLayer.BATCH,
        conv_mode=ConvMode.SAME,
        dim=Dimensions.TWO,
        up_mode=up_mode,
    )

    inp = torch.rand(size=(batch_size, in_channels, height, width), dtype=torch.float32)
    out = unet(inp)
    isEqual = out.shape == (batch_size, out_channels, height, width)
    print("correct: ", isEqual)
    assert out.shape == (batch_size, out_channels, height, width)


test_unet_2d_up_modes(UpMode.TRANSPOSED)