
import numpy as np
import os    # Traverse folders
import nibabel as nib #nii Format 1 This bag will be used in general
import imageio   # Convert to an image
from skimage import img_as_ubyte
import skimage.io as io
 
def nii_to_image(niifile):
 filenames = os.listdir(filepath) # Read nii Folder
 
 for f in filenames:
      # Start reading nii Documents
     if f != ".DS_Store":
        img_path = os.path.join(filepath, f)
        img = nib.load(img_path)    # Read nii
        img_fdata = img.get_fdata()
        fname = f.replace('.nii','')   # Remove nii Suffix name of
        img_f_path = os.path.join(imgfile, fname)
        # Create nii The folder of the corresponding image
        if not os.path.exists(img_f_path):
            os.mkdir(img_f_path)    # New Folder
    
        # Start converting to an image
        (x,y,z) = img.shape
        for i in range(z):      #z Is a sequence of images
            slice = img_fdata[i, :, :]   # You can choose which direction of slice

            # suppose that img's dtype is 'float64'
            img_uint8 = slice.astype(np.uint8)
            # and then
            # imageio.imwrite(os.path.join(img_f_path,'{}.png'.format(i)), img_uint8)
            io.imsave(os.path.join(img_f_path,'{}.png'.format(i)),img_as_ubyte(img_uint8))

            # imageio.imwrite(os.path.join(img_f_path,'{}.png'.format(i)), slice)
                # Save an image 

if __name__ == '__main__':
 filepath = 'dataset/nii'
 imgfile = 'dataset/exported_nii'
 nii_to_image(filepath)
