from skimage import data
import Architecture.utility.napari as napari

# viewer = napari.view_image(data.astronaut(), rgb=True)
# viewer = napari.viewer(data.astronaut(), rgb=True)
viewer = napari.viewer