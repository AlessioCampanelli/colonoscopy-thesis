import pathlib
import os
import re

root = pathlib.Path.cwd()
base_path_inputs = "dataset/normalized"
base_path_targets_masked = "dataset/binary_mask"

def load(path, directly_images):
    elements = []
    folders = os.listdir(path)
    if directly_images:
        for n, image in enumerate(sorted_nicely(folders)):
            elements.append(os.path.join(root, path, image))
        return elements
    else:
        for n, folder in enumerate(folders):
            folder_father = os.path.join(path, folder)
            try:
                images_path2 = os.listdir(folder_father)
                for n, image in enumerate(sorted_nicely(images_path2)): # sorted
                    if image != ".DS_Store":
                        # elements.append(image)
                        elements.append(os.path.join(root, folder_father, image))
            except:
                print("error")
        return elements

def load_inputs(path, directly_images):
    return load(path, directly_images) # base_path_inputs

def load_targets(path, directly_images):
    return load(path, directly_images) #base_path_targets_masked

def sorted_nicely( l ): 
    """ Sort the given iterable in the way that humans expect.""" 
    convert = lambda text: int(text) if text.isdigit() else text 
    alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key) ] 
    return sorted(l, key = alphanum_key)