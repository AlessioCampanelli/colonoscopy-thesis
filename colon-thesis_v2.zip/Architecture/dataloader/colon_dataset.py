import torch
from skimage.io import imread
from torch.utils import data
from PIL import Image
import cv2
import numpy as np

class ColonDataSet(data.Dataset):
    def __init__(self,
                 inputs: list,
                 targets: list,
                 select_class_rgb_values=None,
                 transform=None
                 ):
        self.inputs = inputs
        self.targets = targets
        self.select_class_rgb_values = select_class_rgb_values
        self.transform = transform
        self.inputs_dtype = torch.float32
        self.targets_dtype = torch.long

    def __len__(self):
        return len(self.inputs)

    def __getitem__(self,
                    index: int):
        # Select the sample
        input_ID = self.inputs[index]
        target_ID = self.targets[index]

        # Load input and target
        x, y = imread(input_ID), imread(target_ID)

        # read images and masks
        #x = cv2.cvtColor(cv2.imread(input_ID), cv2.COLOR_BGR2RGB)
        #y = cv2.cvtColor(cv2.imread(target_ID), cv2.COLOR_BGR2RGB)

        # y = one_hot_encode(y, self.select_class_rgb_values).astype('float')

        # Preprocessing
        if self.transform is not None:
            x, y = self.transform(x, y)

        # Typecasting
        x, y = torch.from_numpy(x).type(self.inputs_dtype), torch.from_numpy(y).type(self.targets_dtype)

        return x, y

# Perform one hot encoding on label
def one_hot_encode(label, label_values):
    """
    Convert a segmentation image label array to one-hot format
    by replacing each pixel value with a vector of length num_classes
    # Arguments
        label: The 2D array segmentation image label
        label_values
        
    # Returns
        A 2D array with the same width and hieght as the input, but
        with a depth size of num_classes
    """
    semantic_map = []
    for colour in label_values:
        equality = np.equal(label, colour)
        class_map = np.all(equality, axis = -1)
        semantic_map.append(class_map)
    semantic_map = np.stack(semantic_map, axis=-1)

    return semantic_map