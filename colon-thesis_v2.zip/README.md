# thyroid-thesis

classification of thyroid nodules with attention to the segmentation phase using Convolutional Neural Network in PyTorch

# Setup

- create `dataset/root_data` folders
- in `root_data` folder, create `benign` and `malign` folders containing related JPEG thyroid images

# Structure

- `dataset/root_data` folders to be created at the same height as the other project files
- `start_training.py` the file to launch. Instantiate the network and start the training
- `inference.py` starting a prediction of an image
- `trainer.py` contains train and validation methods.
- `dataloader.py` automatically loads the dataset with the images previously divided into the two folders `benign` and `malign` and apply composed transformations to single image
- `unet.py` contains the Unet Convolutional Network

# Run

- launch `test.py` script
