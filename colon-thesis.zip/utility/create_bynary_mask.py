import cv2
import numpy as np
import pathlib
from skimage.io import imread
import matplotlib.pyplot as plt
from PIL import Image
import imageio

mask_directory = pathlib.Path.cwd() / "dataset/mask"
path_image = mask_directory / "malign/norm-maling22.jpg"
image = imread(path_image)

output = image.copy()
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
# detect circles in the image
circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, 1.0, 40)

# ensure at least some circles were found
if circles is not None:
    # convert the (x, y) coordinates and radius of the circles to integers
    circles = np.round(circles[0, :]).astype("int")
    x, y, r = circles[0]
    cv2.circle(output, (x, y), r, (0, 255, 0), 2)
    # cv2.rectangle(output, (x - 2, y - 2), (x + 2, y + 2), (0, 128, 255), -1)

	# loop over the (x, y) coordinates and radius of the circles
	#for (x, y, r) in circles:
        # draw the circle in the output image, then draw a rectangle
		# corresponding to the center of the circle
		#cv2.circle(output, (x, y), r, (0, 255, 0), 4)
		#cv2.rectangle(output, (x - 5, y - 5), (x + 5, y + 5), (0, 128, 255), -1)
        
	# show the output image
cv2.imshow("output", np.hstack([image, output]))    
cv2.imwrite('test.jpg', np.hstack([output]))
cv2.waitKey(0)

'''image = cv2.resize(image, (image.shape[1] // 4, image.shape[0] // 4))
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
blur = cv2.GaussianBlur(gray, (5, 5), 0)

thresh = cv2.adaptiveThreshold(blur, 255, 1, 1, 11, 2)

contours, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

max_area = 0
best_cnt = None
for counter in contours:
    area = cv2.contourArea(counter)
    if area > 1000:
        if area > max_area:
            max_area = area
            best_cnt = counter

mask = np.zeros((gray.shape), np.uint8)

cv2.drawContours(mask, [best_cnt], 0, 255, -1)
cv2.drawContours(mask, [best_cnt], 0, 0, 2)

cv2.imwrite('mask_jigsaw.jpg', mask)

cv2.imshow("Image Mask", mask)
cv2.waitKey(0)'''