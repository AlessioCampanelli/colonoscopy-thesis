import pydicom as dicom
import os
import cv2
import PIL  # optional

# make it True if you want in PNG format
PNG = False
# Specify the .dcm folder path
base_path = "dataset/original"
# Specify the output jpg/png folder path
jpg_folder_path = "dataset/exported_dicom"
folders = os.listdir(base_path)

for n, folder in enumerate(folders):
    folder_father = os.path.join(base_path, folder)
    try:
        images_path2 = os.listdir(folder_father)
        for n, image in enumerate(images_path2):
            ds = dicom.dcmread(os.path.join(folder_father, image))
            pixel_array_numpy = ds.pixel_array
            if PNG == False:
                image = image.replace(".dcm", ".jpg")
            else:
                image = image.replace(".dcm", ".png")
            pathFolderExport = os.path.join(jpg_folder_path, folder)
            isFolderExportExist = os.path.exists(pathFolderExport)
            if not isFolderExportExist:
                os.makedirs(pathFolderExport)
            cv2.imwrite(
                os.path.join(pathFolderExport, image), pixel_array_numpy,
            )
            if n % 50 == 0:
                print("{} image converted".format(n))
    except NotADirectoryError:
        print("NotADirectoryError catched")
    except:
        print("error")

