import numpy as np
import torch
import sys

sys.path.insert(0, '..')
sys.path.append('Architecture')
sys.path.append('unet')

from Architecture.unet.unet import UNet
import segmentation_models_pytorch as smp

SMOOTH = 1e-6
EPSILON = 1e-32
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# define metrics
metrics = [
    smp.utils.metrics.IoU(threshold=0.5),
]

def classwise_iou(output, gt):
    """
    Args:
        output: torch.Tensor of shape (n_batch, n_classes, image.shape)
        gt: torch.LongTensor of shape (n_batch, image.shape)
    """
    dims = (0, *range(2, len(output.shape)))
    gt = torch.zeros_like(output).scatter_(1, gt[:, None, :], 1)
    intersection = output*gt
    union = output + gt - intersection
    classwise_iou = (intersection.sum(dim=dims).float() + EPSILON) / (union.sum(dim=dims) + EPSILON)

    return classwise_iou

def iou_scoring_metric(outputs: torch.Tensor, labels: torch.Tensor):
    # You can comment out this line if you are passing tensors of equal shape
    # But if you are passing output from UNet or something it will most probably
    # be with the BATCH x 1 x H x W shape
    outputs = outputs.squeeze(1)  # BATCH x 1 x H x W => BATCH x H x W
    
    intersection = (outputs & labels).float().sum((1, 2))  # Will be zero if Truth=0 or Prediction=0
    union = (outputs | labels).float().sum((1, 2))         # Will be zzero if both are 0
    
    iou = (intersection + SMOOTH) / (union + SMOOTH)  # We smooth our devision to avoid 0/0
    
    thresholded = torch.clamp(20 * (iou - 0.5), 0, 10).ceil() / 10  # This is equal to comparing with thresolds
    
    return thresholded  # Or thresholded.mean() if you are interested in average across the batch

class Trainer:
    def __init__(
        self,
        model: torch.nn.Module,
        device: torch.device,
        criterion: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        training_DataLoader: torch.utils.data.Dataset,
        validation_DataLoader: torch.utils.data.Dataset = None,
        lr_scheduler: torch.optim.lr_scheduler = None,
        epochs: int = 100,
        epoch: int = 0,
        notebook: bool = False,
        have_binary_mask: bool = False
    ):

        self.model = model
        self.criterion = criterion
        self.optimizer = optimizer
        self.lr_scheduler = lr_scheduler
        self.training_DataLoader = training_DataLoader
        self.validation_DataLoader = validation_DataLoader
        self.device = device
        self.epochs = epochs
        self.epoch = epoch
        self.notebook = notebook
        self.have_binary_mask = have_binary_mask

        self.training_loss = []
        self.validation_loss = []
        self.learning_rate = []
        self.epoch_training_accuracy = []
        self.epoch_validation_accuracy = []

    def run_trainer(self):

        if self.notebook:
            from tqdm.notebook import tqdm, trange
        else:
            from tqdm import tqdm, trange

        progressbar = trange(self.epochs, desc="Progress")
        for i in progressbar:
            """Epoch counter"""
            self.epoch += 1  # epoch counter

            """Training block"""
            self._train()

            """Validation block"""
            if self.validation_DataLoader is not None:
                self._validate()

            """Learning rate scheduler block"""
            if self.lr_scheduler is not None:
                if (
                    self.validation_DataLoader is not None
                    and self.lr_scheduler.__class__.__name__ == "ReduceLROnPlateau"
                ):
                    # learning rate scheduler step with validation loss
                    self.lr_scheduler.batch(self.validation_loss[i])
                else:
                    self.lr_scheduler.batch()  # learning rate scheduler step
        return self.training_loss, self.validation_loss, self.learning_rate, self.epoch_training_accuracy, self.epoch_validation_accuracy

    def _train(self):

        if self.notebook:
            from tqdm.notebook import tqdm, trange
        else:
            from tqdm import tqdm, trange

        self.model.train()  # train mode
        train_losses = []  # accumulate the losses here
        batch_iter = tqdm(
            enumerate(self.training_DataLoader),
            "Training",
            total=len(self.training_DataLoader),
            leave=False,
        )

        correct = 0
        for i, (x, y) in batch_iter:
            input, target = (
                x.to(self.device),
                y.to(self.device),
            )  # send to device (GPU or CPU)
            self.optimizer.zero_grad()  # zerograd the parameters
            out = self.model(input)  # one forward pass
            
            if isinstance(self.model, UNet):
                # target = torch.argmax(out, dim=1)
                if (self.have_binary_mask):
                    target = target.to(torch.float)

            if isinstance(self.model, smp.Unet):
                target = torch.argmax(out, dim=1)

            # target = target.unsqueeze(-1)
            loss = self.criterion(out, target)  # calculate loss

            loss_value = loss.item()
            train_losses.append(loss_value)
            loss.backward()  # one backward pass
            self.optimizer.step()  # update the parameters+

            out_normalized = out.argmax(dim=1, keepdim=True) # out_normalized = torch.argmax(out, dim=1)
            # correct += (out_normalized == target).float().sum()
            correct += out_normalized.eq(target.view_as(out_normalized)).sum().item()

            batch_iter.set_description(
                f"Training: (loss {loss_value:.4f})"
            )  # update progressbar

        accuracy = (100 * correct) / len(self.training_DataLoader.dataset)

        self.training_loss.append(np.mean(train_losses))
        self.learning_rate.append(self.optimizer.param_groups[0]["lr"])
        self.epoch_training_accuracy.append(float(accuracy))

        batch_iter.close()

    def _validate(self):

        if self.notebook:
            from tqdm.notebook import tqdm, trange
        else:
            from tqdm import tqdm, trange

        self.model.eval()  # evaluation mode
        valid_losses = []  # accumulate the losses here
        batch_iter = tqdm(
            enumerate(self.validation_DataLoader),
            "Validation",
            total=len(self.validation_DataLoader),
            leave=False,
        )

        correct = 0
        for i, (x, y) in batch_iter:
            input, target = (
                x.to(self.device),
                y.to(self.device),
            )  # send to device (GPU or CPU)
            
            with torch.no_grad():
                out = self.model(input)

                # out_norm = torch.argmax(out, dim=1)
                # iou_score = iou_scoring_metric(out_norm, target)
                # print("iou_score: ", iou_score)

                if isinstance(self.model, UNet):
                    # target = torch.argmax(out, dim=1)
                    if (self.have_binary_mask):
                        target = target.to(torch.float)
                if isinstance(self.model, smp.Unet):
                    target = torch.argmax(out, dim=1)
                loss = self.criterion(out, target)
                loss_value = loss.item()
                valid_losses.append(loss_value)

                batch_iter.set_description(f"Validation: (loss {loss_value:.4f})")

            out_normalized = torch.argmax(out, dim=1) # out_normalized = out.argmax(dim=1, keepdim=True)
            # correct += (out_normalized == target).float().sum()
            correct += out_normalized.eq(target.view_as(out_normalized)).sum().item()
            print("target", target)

            # classwise_iou_metric = classwise_iou(out, target)
            # print("classwise_iou", classwise_iou_metric)

            '''if isinstance(self.model, UNet):
                iou_scoring_metric(outputs=out, labels=target) '''

        self.validation_loss.append(np.mean(valid_losses))

        accuracy = (100 * correct) / len(self.validation_DataLoader.dataset)
        self.epoch_validation_accuracy.append(accuracy)
        
        batch_iter.close()