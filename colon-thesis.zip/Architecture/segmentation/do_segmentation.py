# Imports
import sys

sys.path.insert(0, '..')
sys.path.insert(1, '..')
sys.path.append('Architecture')
sys.path.append('unet')

import pathlib
import numpy as np
import torch
import os
from skimage.io import imread

from unet.unet import UNet
import segmentation_models_pytorch as smp
from PIL import Image

model_colonoscopy = 'unet.pt'
model_tirhoyd = 'unet_thyroid.pt'

def start_segmentation():
    # predict directory
    masked_image_directory = pathlib.Path.cwd() / "dataset/normalized"
    export_segmented_image_directory = pathlib.Path.cwd() / "dataset/segmented"

    # device
    if torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        torch.device("cpu")
    # device
    if torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        device = torch.device("cpu")

    model_choosed = input(
        "\n\nCHOOSE MODEL FOR SEGMENTATION:" + 
        "\n- 1. UNet colonoscopy" + 
        "\n- 2. UNet thyroid(u)" +
        "\n- 3. pretrained(p)\n"
    )
    if model_choosed == '1' or model_choosed == '2':
        # model
        model = UNet(
            in_channels=3,
            out_channels=2,
            n_blocks=4,
            start_filters=32,
            activation="relu",
            normalization="batch",
            conv_mode="same",
            dim=2,
        ).to(device)

        # get saved model
        if model_choosed == '1':
            model_name = model_colonoscopy
        elif model_choosed == '2':
            model_name = model_tirhoyd
    elif model_choosed == "p":
        model = smp.Unet(
            encoder_name="efficientnet-b7",  # choose encoder, e.g. mobilenet_v2 or efficientnet-b7
            encoder_weights="imagenet",  # use `imagenet` pre-trained weights for encoder initialization
            in_channels=3,  # model input channels (1 for gray-scale images, 3 for RGB, etc.)
            classes=2,  # model output channels (number of classes in your dataset)
            encoder_depth=5,
        )
        model_name = "pretained.pt"


    # load model just trained (transfer learning applied AND train again on dataset/binary mask)
    model_weights = torch.load(pathlib.Path.cwd() / "models_saved" / model_name)
    model.load_state_dict(model_weights)

    def predict(
        img, model, preprocess, postprocess, device,
    ):
        model.eval()
        img = preprocess(img)  # preprocess image
        x = torch.from_numpy(img).to(device)  # to torch, send to device
        with torch.no_grad():
            out = model(x)  # send through model/network
        if model_choosed == "d":
            out_softmax = torch.softmax(out[0], dim=0)  # perform softmax on outputs
            result = postprocess(out_softmax)  # postprocess outputs
        else:
            out_softmax = torch.softmax(out, dim=1)  # perform softmax on outputs
            result = postprocess(out_softmax)  # postprocess outputs
        return result


    # preprocess function
    def preprocess(img: np.ndarray):
        img = np.moveaxis(img, -1, 0)  # from [H, W, C] to [C, H, W]
        # img = normalize_01(img)  # linear scaling to range [0-1]
        img = np.expand_dims(img, axis=0)  # add batch dimension [B, C, H, W]
        img = img.astype(np.float32)  # typecasting to float32
        return img


    # postprocess function
    def postprocess(img: torch.tensor):
        img = torch.argmax(img, dim=1)  # perform argmax to generate 1 channel
        img = img.cpu().numpy()  # send to cpu and transform to numpy.ndarray
        img = np.squeeze(img)  # remove batch dim and channel dim -> [H, W]
        img = re_normalize(img)  # scale it to the range [0-255]
        return img


    def re_normalize(img):
        img = img.astype("float64")
        img *= 255.0 / img.max()
        return img

    # segments all image in mask folder
    folders = os.listdir(masked_image_directory)
    for n, folder in enumerate(folders):
        folder_father = os.path.join(masked_image_directory, folder)
        try:
            images_path2 = os.listdir(folder_father)
            for n, image in enumerate(images_path2):
                if image != ".DS_Store":
                    path_image_to_segment = os.path.join(folder_father, image)
                    img = imread(masked_image_directory / path_image_to_segment)
                    output = predict(img, model, preprocess, postprocess, device)
                    print("segmented: ", path_image_to_segment)
                    im = Image.fromarray(output)
                    im = im.convert("L")
                    im.save(export_segmented_image_directory / folder / image)
        except NotADirectoryError:
            print("NotADirectoryError catched")
        except:
            print("error")
            
    print("image segmented in ", export_segmented_image_directory)



