from torchvision import transforms, datasets

def load_dataset(data_folder, type_transf):
    transform = {
        "train": transforms.Compose(
            [
                transforms.Resize([375, 295]),  # power of 2 in case of Segnet
                transforms.RandomCrop(224),
                transforms.RandomHorizontalFlip(),
                transforms.ToTensor(),
                # transforms.autoaugment.AutoAugmentPolicy(transforms.autoaugment.AutoAugmentPolicy.IMAGENET),
                transforms.Normalize(
                    mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]
                ),
            ]
        ),
        "test": transforms.Compose(
            [
                transforms.Resize([224, 224]),
                transforms.ToTensor(),
                transforms.Normalize(
                    mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]
                ),
            ]
        ),
        "densenet": transforms.Compose(
            [
                transforms.Resize([293, 256]),
                # transforms.CenterCrop(224)
                transforms.ToTensor(),
                transforms.RandomHorizontalFlip(),
                transforms.Normalize(
                    mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]
                ),
            ]
        ),
    }

    data = datasets.ImageFolder(root=data_folder, transform=transform[type_transf])

    # test element picked in dataset
    batch = data[0]
    x, y = batch
    print(f"x = shape: {x.shape}; type: {x.dtype}")
    print(f"x = min: {x.min()}; max: {x.max()}")
    print(y)

    return data
