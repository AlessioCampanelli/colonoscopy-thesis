import sys
import pathlib
from skimage.transform import resize
from sklearn.model_selection import train_test_split
import torch
import numpy as np

sys.path.insert(0, 'Architecture')
sys.path.append('dataloader')
sys.path.append('segmentation')
sys.path.append('densenet')
sys.path.append('training')

from Architecture.densenet.densenet import DenseNet

from torch.utils.data import DataLoader, Subset, SubsetRandomSampler
from Architecture.dataloader.dataloader import load_dataset
from Architecture.dataloader.thyroid_dataset import ThyroidDataset
from Architecture.dataloader.colon_dataset import ColonDataSet

from Architecture.segmentation.load_normalization_and_binary_mask import load_inputs, load_targets
from Architecture.unet.unet import ActivationFunction, ConvMode, Dimensions, NormalizationLayer, UNet, UpMode
from Architecture.segmentation.do_segmentation import start_segmentation
import segmentation_models_pytorch as smp

from trainer import Trainer
from utility.visual import plot_training


import albumentations
from Architecture.dataloader.transformations import (
    ComposeDouble,
    AlbuSeg2d,
    FunctionWrapperDouble,
    normalize_01,
    create_dense_target,
)

base_path_inputs_thyroid = "dataset/normalized"
base_path_targets_masked_thyroid = "dataset/binary_mask"

base_path_inputs_colonoscopy = "dataset/colonoscopy/original"
base_path_targets_masked_colonoscopy = "dataset/colonoscopy/ground_truth_mask"

ACTION_DENSENET_BASELINE = '1'
ACTION_TRAIN_UNET_COLONOSCOPY = '2'
ACTION_TRAIN_UNET_THYROID_TRANSFER_LEARNING = '3'
ACTION_START_SEGMENTATION = '4'
ACTION_DENSENET_FINAL = '5'
ACTION_UNET_PRATRAINED_IMAGENET = '6'

model_choosed = input(
    "\n\nCHOOSE MODEL TO TRAIN:" +
    "\n- DenseNet (d)" +
    "\n- UNet (u)" +
    "\n- UNet pretrained (p)\n"
)

if model_choosed == "d":
    type_transf = "densenet"
    action_choosed = input(
    "\n\nCHOOSE ACTION TO DO:" + 
    "\n- 1. DenseNet Baseline" + 
    "\n- 5. DenseNet final on segmented dataset\n"
    )
else:
    type_transf = "train"
    action_choosed = input(
    "\n\nCHOOSE ACTION TO DO:" +
    "\n- 2. Train Unet to Transfer Learning (COLONOSCOPY dataset)" +
    "\n- 3. Train Unet on thyroid dataset (transfer learning from colonoscopy)" +
    "\n- 4. Start segmentation (export images)" +
    "\n- 6. Unet pretrained (imagenet)\n"
)

def strat_training(root):
    print("\ntraining STARTED on dataset: ", root)
    print("\n")
    
    if action_choosed == ACTION_DENSENET_BASELINE or action_choosed == ACTION_DENSENET_FINAL:
        # load dataset in case of Transfer learning
        dataset = load_dataset(data_folder=root, type_transf=type_transf)

        # split dataset into training set and validation set
        dataset_train, dataset_test = train_test_split(
                dataset,
                random_state=42,
                train_size=0.8,
                shuffle=True
        )
    elif action_choosed == ACTION_TRAIN_UNET_THYROID_TRANSFER_LEARNING or action_choosed == ACTION_TRAIN_UNET_COLONOSCOPY or action_choosed == ACTION_UNET_PRATRAINED_IMAGENET:
        if model_choosed == "unet" or model_choosed == "u" or model_choosed == "p":

            # load dataset with Binary Mask
            if (action_choosed == ACTION_TRAIN_UNET_THYROID_TRANSFER_LEARNING or action_choosed == ACTION_UNET_PRATRAINED_IMAGENET ):
                inputs = load_inputs(base_path_inputs_thyroid, False)
                targets = load_targets(base_path_targets_masked_thyroid, False)
            elif (action_choosed == ACTION_TRAIN_UNET_COLONOSCOPY):
                inputs = load_inputs(base_path_inputs_colonoscopy, True)
                targets = load_targets(base_path_targets_masked_colonoscopy, True)
            
            inputs_train, inputs_test = train_test_split(
                inputs,
                random_state=42,
                train_size=0.8,
                shuffle=False
            )

            targets_train, targets_test = train_test_split(
                targets,
                random_state=42,
                train_size=0.8,
                shuffle=False
            ) 

            ''' transforms_training = ComposeDouble(
                [
                    FunctionWrapperDouble(
                        resize, input=True, target=False, output_shape=(128, 128, 3)
                    ),
                    FunctionWrapperDouble(normalize_01),
                ]
            )

            transforms_validation = ComposeDouble(
                [
                    FunctionWrapperDouble(
                        resize, input=True, target=False, output_shape=(128, 128, 3)
                    ),
                    FunctionWrapperDouble(create_dense_target, input=False, target=True),
                    FunctionWrapperDouble(
                        np.moveaxis, input=True, target=False, source=-1, destination=0
                    ),
                    FunctionWrapperDouble(normalize_01),
                ]
            ) '''

            # training transformations and augmentations
            transforms_training = ComposeDouble(
                [
                    FunctionWrapperDouble(
                        resize, input=True, target=False, output_shape=(128, 128, 3)
                    ),
                    FunctionWrapperDouble(
                        resize,
                        input=False,
                        target=True,
                        output_shape=(128, 128),
                        order=0,
                        anti_aliasing=False,
                        preserve_range=True,
                    ),
                    AlbuSeg2d(albumentations.HorizontalFlip(p=0.5)),
                    FunctionWrapperDouble(create_dense_target, input=False, target=True),
                    FunctionWrapperDouble(
                        np.moveaxis, input=True, target=False, source=-1, destination=0
                    ),
                    FunctionWrapperDouble(normalize_01),
                ]
            )

            # validation transformations
            transforms_validation = ComposeDouble(
                [
                    FunctionWrapperDouble(
                        resize, input=True, target=False, output_shape=(128, 128, 3)
                    ),
                    FunctionWrapperDouble(
                        resize,
                        input=False,
                        target=True,
                        output_shape=(128, 128),
                        order=0,
                        anti_aliasing=False,
                        preserve_range=True,
                    ),
                    FunctionWrapperDouble(create_dense_target, input=False, target=True),
                    FunctionWrapperDouble(
                        np.moveaxis, input=True, target=False, source=-1, destination=0
                    ),
                    FunctionWrapperDouble(normalize_01),
                ]
            )

            # dataloader<input, mask> in case of Unet
            if (action_choosed == ACTION_TRAIN_UNET_COLONOSCOPY):

                # Useful to shortlist specific classes in datasets with large number of classes
                select_classes = ['background', 'polyp']

                # Get class names
                class_names = ['background', 'polyp']
                # Get class RGB values
                class_rgb_values = [[0, 0, 0], [255, 255, 255]]

                print('All dataset classes and their corresponding RGB values in labels:')
                print('Class Names: ', class_names)
                print('Class RGB values: ', class_rgb_values)

                # Get RGB values of required classes
                select_class_indices = [class_names.index(cls.lower()) for cls in select_classes]
                select_class_rgb_values =  np.array(class_rgb_values)[select_class_indices]

                print('Selected classes and their corresponding RGB values in labels:')
                print('Class Names: ', class_names)
                print('Class RGB values: ', class_rgb_values)


                dataset_train = ColonDataSet(
                    inputs=inputs_train,
                    targets=targets_train,
                    select_class_rgb_values=select_class_rgb_values,
                    transform=transforms_training)
                dataset_test = ColonDataSet(
                    inputs=inputs_test,
                    targets=targets_test,
                    select_class_rgb_values=select_class_rgb_values,
                    transform=transforms_validation)

            elif (action_choosed == ACTION_TRAIN_UNET_THYROID_TRANSFER_LEARNING or action_choosed == ACTION_UNET_PRATRAINED_IMAGENET):
                dataset_train = ThyroidDataset(
                    inputs=inputs_train,
                    targets=targets_train,
                    transform=transforms_training)
                dataset_test = ThyroidDataset(
                    inputs=inputs_test,
                    targets=targets_test,
                    transform=transforms_validation)

    # dataloader training
    dataloader_training = DataLoader(dataset=dataset_train, batch_size=2, shuffle=True)

    # dataloader validation
    dataloader_validation = DataLoader(dataset=dataset_test, batch_size=2, shuffle=True)

    # device
    if torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        device = torch.device("cpu")

    if model_choosed == "unet" or model_choosed == "u":
        # model
        model = UNet(
            in_channels=3,
            out_channels=2,
            n_blocks=4,
            start_filters=32,
            activation= ActivationFunction.RELU,
            normalization= NormalizationLayer.BATCH,
            conv_mode= ConvMode.SAME,
            dim=Dimensions.TWO,
        ).to(device)
    elif model_choosed == "p":
        model = smp.Unet(
            encoder_name="efficientnet-b7",  # choose encoder, e.g. mobilenet_v2 or efficientnet-b7
            encoder_weights="imagenet",  # use `imagenet` pre-trained weights for encoder initialization
            in_channels=3,  # model input channels (1 for gray-scale images, 3 for RGB, etc.)
            classes=2,  # model output channels (number of classes in your dataset)
            activation='sigmoid'
        )

        ''' model = smp.DeepLabV3Plus(
            encoder_name="resnet50",  # choose encoder, e.g. mobilenet_v2 or efficientnet-b7
            encoder_weights="imagenet",  # use `imagenet` pre-trained weights for encoder initialization
            classes=2,  # model input channels (1 for gray-scale images, 3 for RGB, etc.)
            activation='sigmoid'
        ) '''
    else:
        model = DenseNet(num_classes=2)
        # model = torch.hub.load("pytorch/vision:v0.10.0", "densenet121", pretrained=False)

    # criterion

    if action_choosed == ACTION_TRAIN_UNET_THYROID_TRANSFER_LEARNING:  # unet pretrained - use on thyroid
        criterion = torch.nn.MSELoss()
        model_weights = torch.load(pathlib.Path.cwd() / "models_saved/unet.pt") # force weight pretrained
        model.load_state_dict(model_weights)
    elif action_choosed == ACTION_TRAIN_UNET_COLONOSCOPY:
        criterion = torch.nn.CrossEntropyLoss() # torch.nn.MSELoss()
    else:
        criterion = torch.nn.CrossEntropyLoss()

    # optimizer
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01)

    have_binary_mask = (model_choosed == 'u' and (action_choosed == ACTION_TRAIN_UNET_THYROID_TRANSFER_LEARNING or action_choosed == ACTION_TRAIN_UNET_COLONOSCOPY)) # have binary mask in case of our thyroid dataset

    # trainer
    trainer = Trainer(
        model=model,
        device=device,
        criterion=criterion,
        optimizer=optimizer,
        training_DataLoader=dataloader_training,
        validation_DataLoader=dataloader_validation,
        lr_scheduler=None,
        epochs=2,
        epoch=0,
        notebook=True,
        have_binary_mask=have_binary_mask
    )

    # start training
    training_losses, validation_losses, lr_rates, epoch_training_accuracy, epoch_validation_accuracy = trainer.run_trainer()
    print("\n\ntraining_losses: ", training_losses)
    print("validation_losses: ", validation_losses)
    print("lr_rates: ", lr_rates)
    print("epoch training accuracy: ", epoch_training_accuracy)
    print("epoch validation accuracy: ", epoch_validation_accuracy)

    # Plot training results
    flg = plot_training(
        training_losses,
        validation_losses,
        learning_rate=lr_rates,
        gaussian=True,
        sigma=1,
        figsize=(10, 4),
    )

    # save model
    if (model_choosed == "unet" or model_choosed == "u") and action_choosed == ACTION_TRAIN_UNET_COLONOSCOPY:
        model_name = "unet.pt"
    if (model_choosed == "unet" or model_choosed == "u") and action_choosed == ACTION_TRAIN_UNET_THYROID_TRANSFER_LEARNING:
        model_name = "unet_thyroid.pt"
    elif model_choosed == "p":
        model_name = "pretained.pt"
    else:
        model_name = "densenet_saved.pt"

    torch.save(model.state_dict(), pathlib.Path.cwd() / "models_saved" / model_name)

if action_choosed == ACTION_DENSENET_BASELINE or action_choosed == ACTION_TRAIN_UNET_THYROID_TRANSFER_LEARNING or action_choosed == ACTION_UNET_PRATRAINED_IMAGENET:
    dataset_to_process = "dataset/normalized"        # initial normalized images fed to the inital DenseNet or Unet
    root = (pathlib.Path.cwd() / dataset_to_process)
    strat_training(root=root)
#elif action_choosed == ACTION_TRAIN_UNET_COLONOSCOPY:
 #   dataset_to_process = "dataset/exported_nii/"        # heart images for training Unet (transfer learning)
  #  root = (pathlib.Path.cwd() / dataset_to_process)
   # strat_training(root=root)
elif action_choosed == ACTION_START_SEGMENTATION:
    start_segmentation()
elif action_choosed == '5':
    dataset_to_process = "dataset/segmented"           # segmented thyroidal images by Unet
    root = (pathlib.Path.cwd() / dataset_to_process)
    strat_training(root=root)
elif action_choosed == ACTION_TRAIN_UNET_COLONOSCOPY:
    dataset_to_process = "dataset/colonoscopy/original"           # segmented thyroidal images by Unet
    root = (pathlib.Path.cwd() / dataset_to_process)
    strat_training(root=root)
else:
    dataset_to_process = None

if dataset_to_process != None:
    print("\ntraining FINISHED on dataset: ", dataset_to_process)